
package pusher;

// Dummy
public class HTTPResponse {

}
