
package pusher;


public class Log {
	public static void warn(String message) {
		System.out.println(message);		
	}
}
