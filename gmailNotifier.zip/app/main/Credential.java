
package main;


public class Credential {
	public static String ID = "personacubic@gmail.com";
	public static String PW = "11112222";
	
	public static String PusherAppID = "25487";
	public static String PusherKey = "95189161bfb8e7276632";
	public static String PusherSecret = "22f2872cc34a6c407331";		
}
